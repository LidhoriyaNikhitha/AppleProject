package com.mcart.mcartapp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcart.mcartapp.dto.CustomerDTO;
import com.mcart.mcartapp.entity.Customer;
import com.mcart.mcartapp.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	CustomerRepository customerrepository;
	@Autowired
	RatingService ratingservice;

	public CustomerDTO gethighratedcustomer() throws Exception {
		// TODO Auto-generated method stub
		
		List<Customer> mlist = customerrepository.findAll();
		if(mlist == null) {
			throw new Exception("No customers found in repository");
		}
		Customer mres =null;
		int rating =0;
		for(Customer m : mlist) {
			if(m.getCustomerRating()>rating)
			{
				mres = m;
				rating = mres.getCustomerRating();
			}
		}
		CustomerDTO cres= new CustomerDTO();
		cres.setCustomerAverageRating(mres.getCustomerRating());
		cres.setFirstName(mres.getFirstname());
		cres.setLastName(mres.getLastname());
		cres.setId(mres.getCustomerId());
		cres.setAverageRating(ratingservice.getTotalAverageRating());
		return cres;
	}

}
