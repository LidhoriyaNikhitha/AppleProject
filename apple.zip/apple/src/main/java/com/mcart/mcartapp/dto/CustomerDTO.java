package com.mcart.mcartapp.dto;

public class CustomerDTO {
	int id;
	String firstName;
	String lastName;
	int customerAverageRating;
	int averageRating;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getCustomerAverageRating() {
		return customerAverageRating;
	}
	public void setCustomerAverageRating(int customerAverageRating) {
		this.customerAverageRating = customerAverageRating;
	}
	public int getAverageRating() {
		return averageRating;
	}
	public void setAverageRating(int averageRating) {
		this.averageRating = averageRating;
	}

}
