package com.mcart.mcartapp.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.mcart.mcartapp.entity.Rating;

@Repository
public interface ratingrepository extends JpaRepository<Rating,Integer>{
	@Query("select avg(rating) from Rating")
	int getTotalAverageRating();
	@Query("select avg(rating) from Rating where movieId=?1 group by movieId")
	int getmovierating(int movieId);
	@Query("select avg(rating) from Rating where customerId=?1 group by customerId")
	int getcustomerrating(int customerId);
	

}
