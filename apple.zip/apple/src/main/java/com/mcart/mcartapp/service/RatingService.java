package com.mcart.mcartapp.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mcart.mcartapp.entity.Customer;
import com.mcart.mcartapp.entity.Movie;
import com.mcart.mcartapp.entity.Rating;
import com.mcart.mcartapp.repository.CustomerRepository;
import com.mcart.mcartapp.repository.movierepository;
import com.mcart.mcartapp.repository.ratingrepository;

@Service
public class RatingService {
	@Autowired
	ratingrepository ratingrepository;
	@Autowired
	CustomerRepository customerrepository;
	@Autowired
	movierepository movierepository;
	private int ratingId=1;

	public String newRating(int customerId, int rating,int movieId) throws Exception {
		// TODO Auto-generated method stub
		//try {
		Rating r= new Rating();
		r.setMovieId(movieId);
		r.setRating(rating);
		r.setCustomerId(customerId);
		r.setRatingId(ratingId);
		ratingId+=1;
		ratingrepository.saveAndFlush(r);
		updatemovierating(movieId);
		updatecustomerrating(customerId);
		return "Rating submitted successfully";
		
		/*}
		catch(Exception e)
		{
			throw new Exception(e.getMessage());
		}*/
	}

	private void updatecustomerrating(int customerId) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				int avgrating = ratingrepository.getcustomerrating(customerId);
				Optional<Customer> m =  customerrepository.findById(customerId);
				if(m!=null)
				{
					Customer mov = m.get();
					mov.setCustomerRating(avgrating);
					customerrepository.saveAndFlush(mov);
				}
		
	}
	private void updatemovierating(int movieId) {
		// TODO Auto-generated method stub
		int avgrating = ratingrepository.getmovierating(movieId);
		Optional<Movie> m =  movierepository.findById(movieId);
		if(m!=null)
		{
			Movie mov = m.get();
			mov.setRating(avgrating);
			movierepository.saveAndFlush(mov);
		}
		
	}
	public int getTotalAverageRating() {
		// TODO Auto-generated method stub
		return ratingrepository.getTotalAverageRating();
	}
}
