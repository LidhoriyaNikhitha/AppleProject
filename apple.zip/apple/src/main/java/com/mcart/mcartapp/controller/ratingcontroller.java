package com.mcart.mcartapp.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.mcart.mcartapp.dto.CustomerDTO;
import com.mcart.mcartapp.dto.RatingDTO;
import com.mcart.mcartapp.service.CustomerService;
import com.mcart.mcartapp.service.MovieService;
import com.mcart.mcartapp.service.RatingService;

@RestController
@CrossOrigin(origins = "*")
public class ratingcontroller {
	@Autowired
	RatingService ratingservice;
	@Autowired
	MovieService movieservice;
	@Autowired
	CustomerService customerservice;
	@PostMapping(value="/api/rest/customer/{customerId}/rate/{rating}")
	public String newRating(@RequestBody RatingDTO ratingDto, @PathVariable("customerId") int customerId, @PathVariable("rating") int rating) throws Exception{
		return ratingservice.newRating(customerId,rating, ratingDto.getMovieId());
		
	}
	@GetMapping("/highratedmovie")
	public String gethighratedmovie() throws Exception
	{
		//return ratingservice.gethighratedmovie();
		return movieservice.gethighratedmovie();
	}
	@GetMapping("/highratedcustomer")
	public CustomerDTO gethighratedcustomer() throws Exception{
		//return ratingservice.gethighratedcustomer();
		return customerservice.gethighratedcustomer();
		
	}
}
