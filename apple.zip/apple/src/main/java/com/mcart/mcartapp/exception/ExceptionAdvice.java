package com.mcart.mcartapp.exception;



import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;


import com.mcart.mcartapp.util.DisplayMsg;

@RestControllerAdvice
public class ExceptionAdvice {
	@ExceptionHandler(Exception.class)
	public ResponseEntity<DisplayMsg>  exceptionHandler(Exception ex) {
		DisplayMsg d = new DisplayMsg();
		d.setMessage(ex.getMessage());
		return new ResponseEntity<>(d,HttpStatus.OK);
	}
}
