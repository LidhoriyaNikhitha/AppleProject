package com.mcart.mcartapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class McartappApplication {

	public static void main(String[] args) {
		SpringApplication.run(McartappApplication.class, args);
	}

}
